from setuptools import setup

setup(name='distributions',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['distributions'],
      author = 'Abdul Azeem',
      author_email='azeem012001@gmail.com',
      zip_safe=False)